// src/components/Calendario.jsx
import React from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import Tippy from "@tippyjs/react";
import "tippy.js/dist/tippy.css";
import "@fullcalendar/common/index.css";
import "@fullcalendar/daygrid/index.css";
import "@fullcalendar/timegrid/index.css";

export default function Calendario({ entregas = [], onVerDetalle }) {
  const events = entregas.map((e, i) => ({
    id: String(i),
    title: `${e.numeroFactura} – ${e.nombreCliente}`,
    start: `${e.fechaEntrega}T${e.horaEntrega}`,
    extendedProps: e,
    backgroundColor:
      e.estadoEntrega === "en sucursal"
        ? "#f87171"
        : e.estadoEntrega === "en camino"
        ? "#60a5fa"
        : "#34d399",
  }));

  return (
    <div className="bg-white rounded-lg shadow p-4 mb-6">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        headerToolbar={{
          left: "prev,next today",
          center: "title",
          right: "dayGridMonth,timeGridWeek,timeGridDay",
        }}
        events={events}
        eventClick={info => {
          onVerDetalle(info.event.extendedProps);
        }}
        eventDidMount={info => {
          Tippy(info.el, {
            content: `
              <div style="font-size:0.9rem; line-height:1.2">
                <div><strong>Factura:</strong> ${info.event.extendedProps.numeroFactura}</div>
                <div><strong>Cliente:</strong> ${info.event.extendedProps.nombreCliente}</div>
                <div><strong>Tipo:</strong> ${info.event.extendedProps.tipoEntrega}</div>
                <div><strong>Estado:</strong> ${info.event.extendedProps.estadoEntrega}</div>
              </div>`,
            allowHTML: true,
            placement: "top",
          });
        }}
      />
    </div>
  );
}