// postcss.config.js (ESM)
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  }
};