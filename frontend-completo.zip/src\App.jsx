// src/App.jsx
import React, { useState, useEffect } from "react";
import EnvioForm from "./components/EnvioForm";
import FilterBar from "./components/FilterBar";
import ExportButton from "./components/ExportButton";
// import KanbanBoard from "./components/KanbanBoard";
// import Calendario from "./components/Calendario";
import DetailsPanel from "./components/DetailsPanel";

export default function App() {
  console.log("🚀 App.jsx arrancó correctamente");

  // — Estados —
  const [envios, setEnvios] = useState([]);
  const [filtroSucursal, setFiltroSucursal] = useState("");
  const [filtroTipo, setFiltroTipo] = useState("");
  const [selectedEntrega, setSelectedEntrega] = useState(null);

  // — Carga inicial de localStorage —
  useEffect(() => {
    const guardados = JSON.parse(localStorage.getItem("entregas") || "[]");
    setEnvios(guardados);
  }, []);

  // — Guarda en localStorage al cambiar envios —
  useEffect(() => {
    localStorage.setItem("entregas", JSON.stringify(envios));
  }, [envios]);

  // — Agrega una nueva entrega —
  const agregarEntrega = (entrega) => {
    setEnvios((prev) => [entrega, ...prev]);
  };

  // — Selecciona una entrega para ver detalles —
  const handleSelectEntrega = (entrega) => {
    setSelectedEntrega(entrega);
  };

  // — Cierra el panel de detalles —
  const handleCloseDetails = () => {
    setSelectedEntrega(null);
  };

  // — Elimina la entrega seleccionada —
  const handleDelete = () => {
    if (window.confirm("¿Eliminar esta entrega?")) {
      setEnvios((prev) => prev.filter((e) => e !== selectedEntrega));
      handleCloseDetails();
    }
  };

  // — Cambia el estado con contraseña —
  const handleChangeStatus = () => {
    const pwd = prompt("Contraseña para cambiar estatus:");
    if (pwd !== "1234") {
      alert("🔒 Contraseña incorrecta");
      return;
    }

    const current = selectedEntrega.estadoEntrega;
    let next;

    if (current === "en sucursal") {
      next = "en camino";
    } else if (current === "en camino") {
      next = "entregado";
    } else {
      alert("⚠️ Ya está en estado final.");
      return;
    }

    // — Esta línea no debe fallar —
    const updated = { ...selectedEntrega, estadoEntrega: next };

    setEnvios((prev) =>
      prev.map((e) => (e === selectedEntrega ? updated : e))
    );
    setSelectedEntrega(updated);
  };

  // — Filtra envíos por sucursal y tipo —
  const enviosFiltrados = envios.filter(
    (e) =>
      (filtroSucursal ? e.sucursal === filtroSucursal : true) &&
      (filtroTipo ? e.tipoEntrega === filtroTipo : true)
  );

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      {/* 1) Formulario de registro */}
      <EnvioForm onAgregarEntrega={agregarEntrega} />

      {/* 2) Barra de filtros */}
      <FilterBar
        filtroSucursal={filtroSucursal}
        setFiltroSucursal={setFiltroSucursal}
        filtroTipo={filtroTipo}
        setFiltroTipo={setFiltroTipo}
      />

      {/* 3) Botón exportar */}
      <ExportButton datos={enviosFiltrados} />

      {/* 4) Kanban y Calendario (descomentar uno a la vez) */}
      {/*
      <KanbanBoard
        envios={enviosFiltrados}
        onVerDetalle={handleSelectEntrega}
      />
      */}
      {/*
      <Calendario
        entregas={enviosFiltrados}
        onVerDetalle={handleSelectEntrega}
      />
      */}

      {/* 5) Panel de detalles */}
      {selectedEntrega && (
        <DetailsPanel
          entrega={selectedEntrega}
          onClose={handleCloseDetails}
          onDelete={handleDelete}
          onChangeStatus={handleChangeStatus}
        />
      )}
    </div>
  );
}