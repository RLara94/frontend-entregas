import React from "react";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

function ExportButton({ datos }) {
  const exportarExcel = () => {
    const hoja = XLSX.utils.json_to_sheet(datos);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, "Entregas");

    const archivoExcel = XLSX.write(libro, { bookType: "xlsx", type: "array" });
    const blob = new Blob([archivoExcel], { type: "application/octet-stream" });
    saveAs(blob, "entregas_packlife.xlsx");
  };

  return (
    <button
      onClick={exportarExcel}
      className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded shadow mb-4"
    >
      📤 Exportar entregas a Excel
    </button>
  );
}

export default ExportButton;