// src/components/DetailsPanel.jsx
import React from "react";

export default function DetailsPanel({ entrega, onClose, onDelete, onChangeStatus }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-start pt-24">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
        {/* Cerrar */}
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700 text-xl"
        >
          &times;
        </button>

        <h2 className="text-2xl font-bold mb-4">Detalles de Entrega</h2>
        <div className="space-y-2 text-gray-800">
          <div><strong>Factura:</strong> {entrega.numeroFactura}</div>
          <div><strong>Cliente:</strong> {entrega.nombreCliente}</div>
          <div><strong>Monto:</strong> ${entrega.montoFactura}</div>
          <div><strong>Tipo:</strong> {entrega.tipoEntrega}</div>
          {entrega.tipoEntrega === "fletera" && (
            <>
              <div><strong># Guía:</strong> {entrega.numeroGuia}</div>
              <div>
                <strong>Fletera:</strong> {entrega.fletera}{" "}
                {entrega.linkSeguimiento && (
                  <a href={entrega.linkSeguimiento} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">
                    Seguimiento
                  </a>
                )}
              </div>
            </>
          )}
          <div><strong>Fecha:</strong> {entrega.fechaEntrega}</div>
          <div><strong>Hora:</strong> {entrega.horaEntrega}</div>
          <div><strong>Estado:</strong> {entrega.estadoEntrega}</div>
        </div>

        <div className="mt-6 flex justify-between">
          <button
            onClick={onChangeStatus}
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded"
          >
            Cambiar Estatus
          </button>
          <button
            onClick={onDelete}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
          >
            Eliminar
          </button>
        </div>
      </div>
    </div>
  );
}