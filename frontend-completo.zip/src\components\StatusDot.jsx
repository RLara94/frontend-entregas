import React from "react";

// Mapeo de estado a color Tailwind
const estadoColor = {
  "en sucursal": "bg-red-500",
  "en camino":   "bg-yellow-500",
  "entregado":   "bg-green-500",
};

export default function StatusDot({ estado, size = 2 }) {
  const colorClass = estadoColor[estado] || "bg-gray-400";
  const dimension = `${size}rem`;
  return (
    <span
      className={`${colorClass} inline-block rounded-full`}
      style={{ width: dimension, height: dimension }}
    />
  );
}