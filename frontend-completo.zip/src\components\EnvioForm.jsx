// src/components/EnvioForm.jsx
import React, { useState } from "react";

// 1️⃣ Estado inicial centralizado
const ESTADO_INICIAL = {
  numeroFactura: "",
  nombreCliente: "",
  montoFactura: "",
  tipoEntrega: "local",
  numeroGuia: "",
  fletera: "",
  linkSeguimiento: "",
  fechaEntrega: "",
  horaEntrega: "",
  estadoEntrega: "en sucursal",
};

function EnvioForm({ onAgregarEntrega }) {
  const [entrega, setEntrega] = useState(ESTADO_INICIAL);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "tipoEntrega") {
      if (value !== "fletera") {
        setEntrega({
          ...entrega,
          tipoEntrega: value,
          numeroGuia: "",
          fletera: "",
          linkSeguimiento: "",
        });
      } else {
        setEntrega({ ...entrega, tipoEntrega: value });
      }
    } else {
      setEntrega({ ...entrega, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("🛎️ Envío enviado");                             // <-- confirma
    console.log("EnvioForm datos:", entrega);               // <-- log
    onAgregarEntrega(entrega);
    setEntrega(ESTADO_INICIAL);                            // <-- reset correcto
  };

  // Tailwind classes reutilizables
  const inputClass =
    "mt-1 block w-full border border-gray-300 rounded px-3 py-2";

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-lg shadow p-6 mb-6 border border-gray-300"
    >
      <h2 className="text-2xl font-semibold text-blue-800 mb-4">
        Registrar Entrega
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input
          type="text"
          name="numeroFactura"
          value={entrega.numeroFactura}
          onChange={handleChange}
          placeholder="Número de factura"
          className={inputClass}
          required
        />

        <input
          type="text"
          name="nombreCliente"
          value={entrega.nombreCliente}
          onChange={handleChange}
          placeholder="Nombre del cliente"
          className={inputClass}
          required
        />

        <input
          type="number"
          name="montoFactura"
          value={entrega.montoFactura}
          onChange={handleChange}
          placeholder="Monto $"
          className={inputClass}
          required
        />

        <select
          name="tipoEntrega"
          value={entrega.tipoEntrega}
          onChange={handleChange}
          className={inputClass}
          required
        >
          <option value="local">Local</option>
          <option value="foranea">Foránea</option>
          <option value="fletera">Fletera</option>
        </select>

        {entrega.tipoEntrega === "fletera" && (
          <>
            <input
              type="text"
              name="numeroGuia"
              value={entrega.numeroGuia}
              onChange={handleChange}
              placeholder="Número de guía"
              className={inputClass}
            />
            <input
              type="text"
              name="fletera"
              value={entrega.fletera}
              onChange={handleChange}
              placeholder="Nombre de fletera"
              className={inputClass}
            />
            <input
              type="text"
              name="linkSeguimiento"
              value={entrega.linkSeguimiento}
              onChange={handleChange}
              placeholder="Link de seguimiento"
              className={inputClass}
            />
          </>
        )}

        <input
          type="date"
          name="fechaEntrega"
          value={entrega.fechaEntrega}
          onChange={handleChange}
          className={inputClass}
          required
        />

        <input
          type="time"
          name="horaEntrega"
          value={entrega.horaEntrega}
          onChange={handleChange}
          className={inputClass}
          required
        />

        <select
          name="estadoEntrega"
          value={entrega.estadoEntrega}
          onChange={handleChange}
          className={inputClass}
          required
        >
          <option value="en sucursal">En sucursal</option>
          <option value="en camino">En camino</option>
          <option value="entregado">Entregado</option>
        </select>
      </div>

      <div className="mt-4">
        <button
          type="submit"
          className="w-full bg-blue-700 hover:bg-blue-800 text-white px-6 py-2 rounded transition duration-200"
        >
          Registrar Entrega
        </button>
      </div>
    </form>
  );
}

export default EnvioForm;