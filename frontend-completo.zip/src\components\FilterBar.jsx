import React from "react";

function FilterBar({ filtroSucursal, setFiltroSucursal, filtroTipo, setFiltroTipo }) {
  return (
    <div className="bg-white p-4 rounded shadow mb-4 flex flex-col md:flex-row gap-4">
      <div className="flex-1">
        <label className="block font-semibold mb-1">Filtrar por sucursal:</label>
        <select
          value={filtroSucursal}
          onChange={(e) => setFiltroSucursal(e.target.value)}
          className="border p-2 rounded w-full"
        >
          <option value="">Todas</option>
          <option value="Guadalajara">Guadalajara</option>
          <option value="Monterrey">Monterrey</option>
          <option value="CDMX">CDMX</option>
          <option value="Playa del Carmen">Playa del Carmen</option>
        </select>
      </div>

      <div className="flex-1">
        <label className="block font-semibold mb-1">Filtrar por tipo de entrega:</label>
        <select
          value={filtroTipo}
          onChange={(e) => setFiltroTipo(e.target.value)}
          className="border p-2 rounded w-full"
        >
          <option value="">Todos</option>
          <option value="local">Local</option>
          <option value="foranea">Foránea</option>
          <option value="fletera">Fletera</option>
        </select>
      </div>
    </div>
  );
}

export default FilterBar;